<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Modelo Carton
 * Representa un cartón de bingo en la base de datos.
 *
 * Campos clave:
 * - id            : Identificador interno técnico (autoincremental)
 * - numero_carton : Número público mágico para sorteos (6 dígitos, irrepetible)
 * - serie         : Serie del juego (ej: ARG-2026-01)
 * - formato       : Tipo de cartón (ARG, USA, etc.)
 * - grilla        : Matriz 3x9 en JSON con números y ceros
 * - estado        : disponible, vendido, anulado, etc.
 */
class Carton extends Model
{
    use HasFactory;

    /**
     * Nombre real de la tabla en MySQL
     */
    protected $table = 'cartons';

    /**
     * Campos que se pueden asignar masivamente
     * al crear cartones desde el sistema.
     */
    protected $fillable = [
        'serie',          // Serie del juego (ej: ARG-2026-01)
        'numero_carton', // Número mágico público (6 dígitos, irrepetible)
        'formato',       // Formato del cartón (ARG-3x9, USA-5x5, etc.)
        'grilla',        // Matriz de números (JSON)
        'estado',        // Estado comercial (disponible, vendido, anulado, etc.)
    ];

    /**
     * Cast automático para convertir la grilla
     * desde JSON a array de PHP y viceversa.
     */
    protected $casts = [
        'grilla' => 'array',
    ];
}
