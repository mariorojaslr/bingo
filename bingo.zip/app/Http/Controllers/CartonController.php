<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Carton;
use App\Services\PdfService;

class CartonController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | GENERACIÓN DE CARTONES
    |--------------------------------------------------------------------------
    */

    public function generarCartones(Request $request)
    {
        $request->validate([
            'cantidad' => 'required|integer|min:1|max:50000',
            'serie' => 'required|string'
        ]);

        $cantidad = (int) $request->cantidad;
        $serie = $request->serie;

        for ($i = 1; $i <= $cantidad; $i++) {

            // Generar número mágico irrepetible de 6 dígitos
            do {
                $numeroMagico = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
            } while (Carton::where('numero_carton', $numeroMagico)->exists());

            Carton::create([
                'serie' => $serie,
                'numero_carton' => $numeroMagico, // número público para sorteos
                'formato' => 'ARG',
                'estado' => 'activo',
                'grilla' => $this->generarGrillaArgentina()
            ]);
        }

        return redirect()->back()->with('success', "Se generaron $cantidad cartones correctamente con números mágicos únicos.");
    }

    /*
    |--------------------------------------------------------------------------
    | VISOR PROFESIONAL DE CARTONES
    |--------------------------------------------------------------------------
    */

    public function listado(Request $request)
    {
        $columnas = (int) $request->get('columnas', 3);
        $filas = (int) $request->get('filas', 2);

        $columnas = max(1, min(4, $columnas));
        $filas = max(1, min(4, $filas));

        $porPagina = $columnas * $filas;

        if ($request->filled('numero')) {
            $numero = $request->numero;
            $posicion = Carton::where('numero_carton', '<=', $numero)->count();
            $pagina = (int) ceil($posicion / $porPagina);
        } else {
            $pagina = $request->get('page', 1);
        }

        $cartones = Carton::orderBy('numero_carton')
            ->paginate($porPagina, ['*'], 'page', $pagina);

        return view('admin.cartones.listado', compact(
            'cartones',
            'columnas',
            'filas',
            'porPagina'
        ));
    }

    /*
    |--------------------------------------------------------------------------
    | IMPRESIÓN DE LOTES (PDF)
    |--------------------------------------------------------------------------
    */

    public function calcularLoteImpresion(Request $request)
    {
        $request->validate([
            'titulo' => 'required|string',
            'organiza' => 'required|string',
            'fecha' => 'required',
            'serie' => 'required|string',
            'desde' => 'required|string',
            'hasta' => 'required|string',
            'cartones_por_hoja' => 'required|in:3,4,6',
            'precio_hoja' => 'required|numeric|min:0',
            'modo_seleccion' => 'required|in:aleatorio,secuencial',
            'texto_pie' => 'nullable|string',
        ]);

        $cantidadCartones = 1; // se calcula visualmente luego
        $cantidadHojas = 1;
        $total = $cantidadHojas * $request->precio_hoja;

        return view('admin.impresion.confirmacion', [
            'datos' => $request->all(),
            'cantidadCartones' => $cantidadCartones,
            'cantidadHojas' => $cantidadHojas,
            'total' => $total
        ]);
    }

    public function generarLotePDF(Request $request, PdfService $pdfService)
    {
        $desde = $request->desde;
        $hasta = $request->hasta;
        $cartonesPorHoja = (int)$request->cartones_por_hoja;
        $modo = $request->modo_seleccion;

        $query = Carton::whereBetween('numero_carton', [$desde, $hasta]);

        if ($modo === 'aleatorio') {
            $query->inRandomOrder();
        } else {
            $query->orderBy('numero_carton');
        }

        $cartones = $query->get();
        $grupos = $cartones->chunk($cartonesPorHoja);
        $totalHojas = $grupos->count();

        $evento = [
            'titulo' => $request->titulo,
            'organiza' => $request->organiza,
            'fecha' => $request->fecha,
            'serie' => $request->serie,
            'lote' => now()->format('YmdHis'),
            'texto_pie' => $request->texto_pie,
            'modo' => $modo,
        ];

        $html = view('admin.impresion.modos.lote_estandar', [
            'evento' => $evento,
            'grupos' => $grupos,
            'totalHojas' => $totalHojas,
        ])->render();

        $mpdf = $pdfService->make([
            'format' => 'A4',
            'orientation' => 'P'
        ]);

        $mpdf->WriteHTML($html);

        return $mpdf->Output(
            'Lote_' . $evento['serie'] . '_' . $desde . '_al_' . $hasta . '.pdf',
            'D'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | GENERADOR DE GRILLA ARGENTINA 3x9
    |--------------------------------------------------------------------------
    */

    private function generarGrillaArgentina()
    {
        $rangos = [
            range(1,9), range(10,19), range(20,29),
            range(30,39), range(40,49), range(50,59),
            range(60,69), range(70,79), range(80,90)
        ];

        $grilla = array_fill(0, 3, array_fill(0, 9, 0));

        for ($fila = 0; $fila < 3; $fila++) {
            $columnasConNumero = array_rand(range(0,8), 5);

            foreach ($columnasConNumero as $col) {
                $numero = $rangos[$col][array_rand($rangos[$col])];
                $grilla[$fila][$col] = $numero;
            }
        }

        return $grilla;
    }
}
