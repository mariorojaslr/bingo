<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Jugada;
use App\Models\Organizador;
use App\Models\Institucion;
use App\Models\Carton;
use Illuminate\Support\Facades\DB;

class JugadaController extends Controller
{
    /**
     * Listado de jugadas
     */
    public function index()
    {
        $jugadas = Jugada::with(['organizador', 'institucion'])
            ->orderBy('created_at', 'desc')
            ->get();

        return view('admin.jugadas.index', compact('jugadas'));
    }

    /**
     * Formulario de creación de jugada
     */
    public function create()
    {
        $organizadores = Organizador::where('activo', 1)->get();
        $instituciones = Institucion::where('activa', 1)->get();

        return view('admin.jugadas.create', compact('organizadores', 'instituciones'));
    }

    /**
     * Guardar nueva jugada
     */
    public function store(Request $request)
    {
        $request->validate([
            'organizador_id'    => 'required|exists:organizadores,id',
            'institucion_id'    => 'required|exists:instituciones,id',
            'nombre_jugada'     => 'required|string|max:255',
            'fecha_evento'      => 'required|date',
            'hora_evento'       => 'nullable',
            'lugar'             => 'nullable|string|max:255',
            'cartones_por_hoja' => 'required|in:3,6',
        ]);

        Jugada::create([
            'organizador_id'    => $request->organizador_id,
            'institucion_id'    => $request->institucion_id,
            'nombre_jugada'     => $request->nombre_jugada,
            'fecha_evento'      => $request->fecha_evento,
            'hora_evento'       => $request->hora_evento,
            'lugar'             => $request->lugar,
            'cartones_por_hoja' => $request->cartones_por_hoja,
            'estado'            => 'creada',
        ]);

        return redirect()->route('admin.jugadas.index')
            ->with('success', 'Jugada creada correctamente.');
    }

    /**
     * Vista detalle de una jugada
     */
    public function show($id)
    {
        $jugada = Jugada::with(['organizador', 'institucion'])->findOrFail($id);

        $lotes = DB::table('jugada_carton')
            ->select(
                'lote_impresion',
                DB::raw('COUNT(*) as cantidad'),
                DB::raw('MIN(created_at) as fecha')
            )
            ->where('jugada_id', $id)
            ->groupBy('lote_impresion')
            ->orderBy('fecha')
            ->get();

        return view('admin.jugadas.show', compact('jugada', 'lotes'));
    }

    /**
     * Visor de cartones de una jugada (pantalla completa)
     */
    public function cartones($id)
    {
        $jugada = Jugada::findOrFail($id);

        return view('admin.jugadas.cartones', compact('jugada'));
    }

    /**
     * Crear un nuevo lote de impresión (reserva de cartones)
     */
    public function crearLote(Request $request, $jugadaId)
    {
        $jugada = Jugada::findOrFail($jugadaId);

        $request->validate([
            'cantidad_cartones' => 'nullable|integer|min:1',
            'cantidad_hojas'    => 'nullable|integer|min:1',
            'precio_hoja'       => 'required|numeric|min:0',
        ]);

        if (!$request->cantidad_cartones && !$request->cantidad_hojas) {
            return back()->withErrors('Debe indicar cantidad de cartones o de hojas.');
        }

        $porHoja = $jugada->cartones_por_hoja;

        // Calcular cartones y hojas
        if ($request->cantidad_cartones) {
            $cantidadCartones = $request->cantidad_cartones;
            $cantidadHojas = (int) ceil($cantidadCartones / $porHoja);
        } else {
            $cantidadHojas = $request->cantidad_hojas;
            $cantidadCartones = $cantidadHojas * $porHoja;
        }

        // Generar código de lote secuencial por jugada
        $ultimoLote = DB::table('jugada_carton')
            ->where('jugada_id', $jugadaId)
            ->max('lote_impresion');

        $numeroLote = $ultimoLote
            ? intval(substr($ultimoLote, -3)) + 1
            : 1;

        $codigoLote = 'JUG-' . str_pad($jugadaId, 4, '0', STR_PAD_LEFT)
                    . '-L' . str_pad($numeroLote, 3, '0', STR_PAD_LEFT);

        // Obtener cartones libres (no usados en esta jugada)
        $cartonesUsados = DB::table('jugada_carton')
            ->where('jugada_id', $jugadaId)
            ->pluck('carton_id')
            ->toArray();

        $cartonesDisponibles = Carton::whereNotIn('id', $cartonesUsados)
            ->limit($cantidadCartones)
            ->get();

        if ($cartonesDisponibles->count() < $cantidadCartones) {
            return back()->withErrors('No hay suficientes cartones disponibles.');
        }

        // Asignar cartones al lote
        $hoja = 1;
        $posicion = 1;

        foreach ($cartonesDisponibles as $carton) {

            DB::table('jugada_carton')->insert([
                'jugada_id'       => $jugadaId,
                'carton_id'       => $carton->id,
                'lote_impresion'  => $codigoLote,
                'numero_hoja'     => $hoja,
                'posicion_en_hoja'=> $posicion,
                'estado'          => 'asignado',
                'created_at'      => now(),
                'updated_at'      => now(),
            ]);

            $posicion++;

            if ($posicion > $porHoja) {
                $posicion = 1;
                $hoja++;
            }
        }

        // Actualizar totales en la jugada
        $jugada->cantidad_cartones = ($jugada->cantidad_cartones ?? 0) + $cantidadCartones;
        $jugada->cantidad_hojas    = ($jugada->cantidad_hojas ?? 0) + $cantidadHojas;
        $jugada->precio_hoja      = $request->precio_hoja;
        $jugada->total            = $jugada->cantidad_hojas * $jugada->precio_hoja;
        $jugada->estado           = 'en_impresion';
        $jugada->save();

        return redirect()->route('admin.jugadas.show', $jugadaId)
            ->with('success', "Lote $codigoLote generado correctamente.");
    }
}
