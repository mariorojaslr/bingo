<?php $__env->startSection('contenido'); ?>

<h2 class="mb-3">Visor Profesional de Cartones</h2>

<form method="GET" action="<?php echo e(route('admin.cartones.listado')); ?>" class="row g-3 mb-4 align-items-end">

    <div class="col-auto">
        <label class="form-label">Columnas</label>
        <select name="columnas" class="form-select form-select-sm">
            <?php for($i=1;$i<=4;$i++): ?>
                <option value="<?php echo e($i); ?>" <?php echo e(request('columnas',3)==$i?'selected':''); ?>><?php echo e($i); ?></option>
            <?php endfor; ?>
        </select>
    </div>

    <div class="col-auto">
        <label class="form-label">Filas</label>
        <select name="filas" class="form-select form-select-sm">
            <?php for($i=1;$i<=4;$i++): ?>
                <option value="<?php echo e($i); ?>" <?php echo e(request('filas',2)==$i?'selected':''); ?>><?php echo e($i); ?></option>
            <?php endfor; ?>
        </select>
    </div>

    <div class="col-auto">
        <label class="form-label">Ir al cartón Nº</label>
        <input type="number" name="numero" class="form-control form-control-sm" placeholder="Ej: 322">
    </div>

    <div class="col-auto">
        <button class="btn btn-primary btn-sm">Aplicar</button>
    </div>

</form>

<div class="row">

<?php $__currentLoopData = $cartones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carton): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php $grilla = is_array($carton->grilla) ? $carton->grilla : json_decode($carton->grilla, true); ?>

    <div class="col-md-<?php echo e(12 / $columnas); ?> mb-4">

        <div class="border p-2 bg-white shadow-sm">

            <div class="fw-bold mb-1">Cartón Nº <?php echo e($carton->numero_carton); ?></div>

            <table class="tabla-bingo">
                <?php $__currentLoopData = $grilla; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php $__currentLoopData = $fila; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($valor == 0): ?>
                                <td class="vacio"></td>
                            <?php else: ?>
                                <td class="numero"><?php echo e($valor); ?></td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

        </div>

    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<div class="d-flex justify-content-center mt-3">
    <?php echo e($cartones->withQueryString()->links()); ?>

</div>

<style>
.tabla-bingo {
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
}

.tabla-bingo td {
    border: 1px solid #000;
    height: 42px;
    text-align: center;
    vertical-align: middle;
    font-family: Helvetica, Arial, sans-serif;
    font-size: 22px;
    font-weight: bold;
}

.tabla-bingo td.numero {
    background: #ffffff;
    color: #000000;
}

.tabla-bingo td.vacio {
    background: #e0e0e0; /* gris 15% */
}
</style>


<style>
/* Normaliza tamaño del paginador */
.pagination {
    font-size: 14px !important;
}

.pagination svg {
    width: 16px !important;
    height: 16px !important;
}

.pagination li {
    margin: 0 2px;
}

.pagination a,
.pagination span {
    padding: 4px 8px !important;
}
</style>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bingo\resources\views/admin/cartones/listado.blade.php ENDPATH**/ ?>