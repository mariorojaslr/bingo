<?php $__env->startSection('contenido'); ?>
<div class="container-fluid">

    <h2 class="mb-3">➕ Crear Nueva Jugada</h2>

    <div class="card card-metric">
        <div class="card-body">

            <form method="POST" action="<?php echo e(route('admin.jugadas.store')); ?>">
                <?php echo csrf_field(); ?>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Organizador</label>
                        <select name="organizador_id" class="form-select" required>
                            <option value="">Seleccione...</option>
                            <?php $__currentLoopData = $organizadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($org->id); ?>">
                                    <?php echo e($org->razon_social ?? $org->nombre_fantasia ?? 'Organizador #' . $org->id); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Institución</label>
                        <select name="institucion_id" class="form-select" required>
                            <option value="">Seleccione...</option>
                            <?php $__currentLoopData = $instituciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($inst->id); ?>">
                                    <?php echo e($inst->nombre); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Nombre de la Jugada</label>
                    <input type="text" name="nombre_jugada" class="form-control" required>
                </div>

                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Fecha del Evento</label>
                        <input type="date" name="fecha_evento" class="form-control" required>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Hora</label>
                        <input type="time" name="hora_evento" class="form-control">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Lugar</label>
                        <input type="text" name="lugar" class="form-control">
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Formato de impresión</label>
                    <select name="cartones_por_hoja" class="form-select">
                        <option value="3">3 cartones por hoja (A4)</option>
                        <option value="6">6 cartones por hoja (doble corte)</option>
                    </select>
                </div>

                <div class="text-end">
                    <a href="<?php echo e(route('admin.jugadas.index')); ?>" class="btn btn-secondary">Cancelar</a>
                    <button class="btn btn-success">
                        <i class="bi bi-save"></i> Guardar Jugada
                    </button>
                </div>

            </form>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bingo\resources\views/admin/jugadas/create.blade.php ENDPATH**/ ?>