<?php $__env->startSection('contenido'); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>📅 Jugadas</h2>
    <a href="<?php echo e(route('admin.jugadas.create')); ?>" class="btn btn-primary">
        ➕ Nueva Jugada
    </a>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <?php if($jugadas->count() == 0): ?>
            <p class="text-muted">No hay jugadas creadas todavía.</p>
        <?php else: ?>
            <table class="table table-striped align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Institución</th>
                        <th>Organizador</th>
                        <th>Fecha</th>
                        <th>Formato</th>
                        <th>Estado</th>
                        <th class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $jugadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jugada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($jugada->id); ?></td>
                            <td><?php echo e($jugada->nombre_jugada); ?></td>
                            <td><?php echo e($jugada->institucion->nombre ?? '—'); ?></td>
                            <td><?php echo e($jugada->organizador->nombre_fantasia ?? '—'); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($jugada->fecha_evento)->format('d/m/Y')); ?></td>
                            <td><?php echo e($jugada->cartones_por_hoja); ?> por hoja</td>
                            <td>
                                <span class="badge bg-primary">
                                    <?php echo e(ucfirst($jugada->estado)); ?>

                                </span>
                            </td>
                            <td class="text-end">
                                <a href="<?php echo e(route('admin.jugadas.show', $jugada->id)); ?>" class="btn btn-sm btn-info">
                                    👁 Ver
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bingo\resources\views/admin/jugadas/index.blade.php ENDPATH**/ ?>