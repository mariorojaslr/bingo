<?php $__env->startSection('contenido'); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>🎯 Jugada: <?php echo e($jugada->nombre_jugada); ?></h2>
    <a href="<?php echo e(route('admin.jugadas.index')); ?>" class="btn btn-secondary">← Volver</a>
</div>

<div class="card mb-4">
    <div class="card-body">
        <div class="row">
            <div class="col-md-4"><strong>Organizador:</strong> <?php echo e($jugada->organizador->nombre_fantasia); ?></div>
            <div class="col-md-4"><strong>Institución:</strong> <?php echo e($jugada->institucion->nombre); ?></div>
            <div class="col-md-4"><strong>Formato:</strong> <?php echo e($jugada->cartones_por_hoja); ?> cartones por hoja</div>
        </div>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between">
        <strong>📦 Lotes de impresión</strong>
        <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#modalNuevoLote">
            ➕ Nuevo Lote
        </button>
    </div>

    <div class="card-body">
        <?php if($lotes->isEmpty()): ?>
            <p class="text-muted">Todavía no hay lotes generados.</p>
        <?php else: ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Lote</th>
                        <th>Fecha</th>
                        <th>Cartones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $lotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($lote->lote_impresion); ?></td>
                            <td><?php echo e($lote->fecha); ?></td>
                            <td><?php echo e($lote->cantidad); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<a href="<?php echo e(route('admin.jugadas.cartones', $jugada->id)); ?>" class="btn btn-primary">
    👁 Ver Cartones de esta Jugada
</a>

<!-- MODAL NUEVO LOTE -->
<div class="modal fade" id="modalNuevoLote" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('admin.jugadas.lotes.crear', $jugada->id)); ?>">
            <?php echo csrf_field(); ?>

            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">📦 Generar Nuevo Lote</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">

                    <div class="mb-3">
                        <label class="form-label">Cantidad de Cartones</label>
                        <input type="number" class="form-control" name="cantidad_cartones" placeholder="Ej: 1000">
                        <small class="text-muted">O dejar vacío y usar hojas</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Cantidad de Hojas</label>
                        <input type="number" class="form-control" name="cantidad_hojas" placeholder="Ej: 300">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Precio por Hoja</label>
                        <input type="number" step="0.01" class="form-control" name="precio_hoja"
                               value="<?php echo e($jugada->precio_hoja); ?>">
                        <small class="text-muted">Se fija en el primer lote y no cambia luego</small>
                    </div>

                    <div class="alert alert-info">
                        Formato fijo: <strong><?php echo e($jugada->cartones_por_hoja); ?> cartones por hoja</strong>
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-success">Generar Lote</button>
                </div>
            </div>

        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bingo\resources\views/admin/jugadas/show.blade.php ENDPATH**/ ?>