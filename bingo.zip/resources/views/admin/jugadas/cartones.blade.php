@extends('admin.layout')

@section('contenido')
<h2>Visor de cartones de la jugada {{ $jugada->nombre_jugada }}</h2>
<p>Acá irá el visor completo con grillas y colores por lote.</p>
@endsection
