<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CartonController;
use App\Http\Controllers\Admin\JugadaController;

/*
|--------------------------------------------------------------------------
| Rutas Públicas
|--------------------------------------------------------------------------
*/

Route::get('/', function () {
    return view('welcome');
});

/*
|--------------------------------------------------------------------------
| Panel de Administración
|--------------------------------------------------------------------------
| Acceso por /admin/...
*/

Route::prefix('admin')->group(function () {

    /*
    |--------------------------------------------------------------------------
    | Dashboard
    |--------------------------------------------------------------------------
    */
    Route::get('/', function () {
        return view('admin.dashboard');
    })->name('admin.dashboard');

    /*
    |--------------------------------------------------------------------------
    | Módulo: Cartones
    |--------------------------------------------------------------------------
    */

    Route::get('/cartones/generar', function () {
        return view('admin.cartones.generar');
    })->name('admin.cartones.generar');

    Route::post('/cartones/generar', [CartonController::class, 'generarCartones'])
        ->name('admin.cartones.store');

    Route::get('/cartones', [CartonController::class, 'listado'])
        ->name('admin.cartones.listado');

    /*
    |--------------------------------------------------------------------------
    | Módulo: Impresión
    |--------------------------------------------------------------------------
    */

    Route::get('/impresion', function () {
        return view('admin.impresion.formulario');
    })->name('admin.impresion.formulario');

    Route::post('/impresion/calcular', [CartonController::class, 'calcularLoteImpresion'])
        ->name('admin.impresion.calcular');

    Route::post('/impresion/generar-pdf', [CartonController::class, 'generarLotePDF'])
        ->name('admin.impresion.generar');

    /*
    |--------------------------------------------------------------------------
    | Módulo: Jugadas
    |--------------------------------------------------------------------------
    */

    // Listado
    Route::get('/jugadas', [JugadaController::class, 'index'])
        ->name('admin.jugadas.index');

    // Crear jugada
    Route::get('/jugadas/crear', [JugadaController::class, 'create'])
        ->name('admin.jugadas.create');

    Route::post('/jugadas', [JugadaController::class, 'store'])
        ->name('admin.jugadas.store');

    // Ver jugada
    Route::get('/jugadas/{jugada}', [JugadaController::class, 'show'])
        ->name('admin.jugadas.show');

    // Visor de cartones de una jugada
    Route::get('/jugadas/{jugada}/cartones', [JugadaController::class, 'cartones'])
        ->name('admin.jugadas.cartones');

    // Crear nuevo lote para una jugada
    Route::post('/jugadas/{jugada}/lotes', [JugadaController::class, 'crearLote'])
        ->name('admin.jugadas.lotes.crear');

});
